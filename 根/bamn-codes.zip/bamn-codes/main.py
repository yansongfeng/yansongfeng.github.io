import os
import pprint
import tensorflow as tf
from model import BAMN
from utils import *

pp = pprint.PrettyPrinter()

flags = tf.app.flags

flags.DEFINE_integer("n_hidden", 300, "internal hidden state dimension [300]")
flags.DEFINE_integer("lindim", 150, "linear part of the state [75]")
flags.DEFINE_integer("nhop", 1, "number of hops [7]")
flags.DEFINE_integer("pad_idx", 0, "pad idx [0]")
flags.DEFINE_integer("batch_size", 16, "batch size to use during training [16]")
flags.DEFINE_integer("nepoch", 200, "number of epoch to use during training [200]")
flags.DEFINE_integer("max_sentence_len", 80, "max token size per sentence [80]" )
flags.DEFINE_integer("max_target_len", 10, "max target size per aspect [10]")
flags.DEFINE_integer("embedding_size", 300, "embedding vector size [300]")
flags.DEFINE_float("init_lr", 0.01, "initial learning rate [0.01]")
flags.DEFINE_float("init_hid", 0.01, "initial internal state value [0.01]")
flags.DEFINE_float("init_std", 0.01, "weight initialization std [0.05]")
flags.DEFINE_float("l2_reg", 0.00001, "l2 regularization item [0.00001]")
flags.DEFINE_float("alignment", 0.5, "alignment [0.5]")
flags.DEFINE_float("keep_prob1", 0.5, "ingress keep prob in dropout mechanism [0.5]")
flags.DEFINE_float("keep_prob2", 0.5, "output keep prob in dropout mechinism [0.5]")
flags.DEFINE_string("summary_dir", "./summary", "summary log directory [./summary]")
flags.DEFINE_string("embedding_file", "./data/laptop_word_embedding_42b.txt", "pre-trained embedding vector file [./data/laptop_word_embedding_42b.txt]")
flags.DEFINE_integer("n_class", 3, "num of classes to predict")
flags.DEFINE_float("max_grad_norm", 100, "clip gradients to this norm [50]")
flags.DEFINE_string("pretrain_file", "data/glove.840B.300d.txt", "pre-trained glove vectors file path [../data/glove.6B.300d.txt]")
flags.DEFINE_string("train_data", "data/laptop_2014_train.txt", "train gold data set path [./data/Laptops_Train.xml.seg]")
flags.DEFINE_string("test_data", "data/laptop_2014_test.txt", "test gold data set path [./data/Laptops_Test_Gold.xml.seg]")
flags.DEFINE_boolean("show", True, "print progress [True]")
flags.DEFINE_boolean("enable_alignment_loss", False, "aspect level alignment loss [False]")
flags.DEFINE_string("alignment_loss_type", "neg", "alignment_loss_type [neg]")

FLAGS = flags.FLAGS
def main(_):
	pp.pprint(flags.FLAGS.__flags)

	with tf.Session() as sess:
	    model = BAMN(FLAGS, sess)
	    model.run()

if __name__ == '__main__':
  tf.app.run()
