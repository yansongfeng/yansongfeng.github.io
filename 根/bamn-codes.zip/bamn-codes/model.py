import tensorflow as tf
from utils import *
from layer import *
import numpy as np

class BAMN(object):
    def __init__(self, config, sess):
        self.init_lr = config.init_lr
        self.init_hid = config.init_hid
        self.init_std = config.init_std
        self.batch_size = config.batch_size
        self.nepoch = config.nepoch
        self.nhop = config.nhop
        self.n_hidden = config.n_hidden
        self.lindim = config.lindim
        self.max_grad_norm = config.max_grad_norm
        self.pad_idx = config.pad_idx
        self.embedding_file = config.embedding_file
        self.embedding_size = config.embedding_size
        self.l2_reg = config.l2_reg
        self.max_sentence_len = config.max_sentence_len
        self.max_target_len = config.max_target_len
        self.n_class = config.n_class
        self.kp1 = config.keep_prob1
        self.kp2 = config.keep_prob2
        self.summary_dir = config.summary_dir
        self.train_data_path = config.train_data
        self.test_data_path = config.test_data
        self.sess = sess
        self.show = config.show
        self.enable_alignment_loss = config.enable_alignment_loss
        self.alignment = config.alignment
        self.alignment_loss_type = config.alignment_loss_type


        with tf.variable_scope("inputs"):
            self.real_batch_size = tf.placeholder(tf.int32)
            self.x = tf.placeholder(tf.int32, [None, self.max_sentence_len])
            self.y = tf.placeholder(tf.float32, [None, self.n_class])
            self.sentence_len = tf.placeholder(tf.int32, None)
            self.sentence_pos = tf.placeholder(tf.float32, [None, self.max_sentence_len])

            self.target = tf.placeholder(tf.int32, [None, self.max_target_len])
            self.target_len = tf.placeholder(tf.int32, [None])
            self.keep_prob1 = tf.placeholder(tf.float32)
            self.keep_prob2 = tf.placeholder(tf.float32)

        # load data
        word_dict = load_word_dict([self.train_data_path, self.test_data_path])
        self.word_to_id, self.w2v, self.id_to_word = load_w2v(self.embedding_file, self.embedding_size, word_dict)
        self.train_data = load_inputs(self.train_data_path, self.word_to_id, self.max_sentence_len, self.max_target_len)
        self.test_data = load_inputs(self.test_data_path, self.word_to_id, self.max_sentence_len, self.max_target_len)


    def build_memory(self):
        self.embedding_layer = tf.constant(self.w2v, name='word_embedding')
        self.C = tf.nn.embedding_lookup(self.embedding_layer, self.x)
        self.T = tf.nn.embedding_lookup(self.embedding_layer, self.target)
        self.C = tf.nn.dropout(self.C, keep_prob=self.keep_prob1)
        self.T = tf.nn.dropout(self.T, keep_prob=self.keep_prob1)
        sentence_mask = get_mask_with_len(self.sentence_len, self.max_sentence_len)
        target_mask = get_mask_with_len(self.target_len, self.max_target_len)
        cell = tf.nn.rnn_cell.LSTMCell
        context = bi_dynamic_rnn(cell, self.C, self.n_hidden, self.sentence_len, self.max_sentence_len, 'context', 'all')
        context = context * tf.expand_dims(self.sentence_pos,2)
        context_avg = reduce_mean_with_len(context, self.sentence_len)
        target_all, target_avg = bi_dynamic_rnn(cell, self.T, self.n_hidden, self.target_len, self.max_target_len, 'target', 'all_and_avg')
        att_c = bilinear_attention_layer(context, target_avg, self.sentence_len, self.init_hid, self.l2_reg, 't_on_c')
        self.att_c = tf.reshape(att_c, [self.real_batch_size, -1])
        att_c_v = tf.reshape(tf.matmul(att_c, context), [self.real_batch_size, -1])
        att_t = bilinear_attention_layer(target_all, context_avg, self.target_len, self.init_hid, self.l2_reg, 'c_on_t')
        att_t_v = tf.reshape(tf.matmul(att_t, target_all), [self.real_batch_size, -1])

        self.alignment_loss = self.alignment * alignment_loss_func(target_avg, att_c, self.y, self.real_batch_size, 2*self.n_hidden, self.init_hid, self.l2_reg, self.alignment_loss_type)

        out = bi_directional_attention(context, target_all, self.sentence_len, sentence_mask, target_mask, self.init_hid, self.l2_reg)
        final = tf.concat([att_c_v, att_t_v, out], 1)
        #self.pred = softmax_layer(final, 6 * self.n_hidden, self.init_hid, self.keep_prob2, self.n_class, self.l2_reg)
        self.pred = softmax_layer(final, 8 * self.n_hidden, self.init_hid, self.keep_prob2, self.n_class, self.l2_reg)

    def build_model(self):
        self.build_memory()
        self.loss = loss_func(self.pred, self.y)
        if self.enable_alignment_loss:
            self.loss += self.alignment_loss
        self.acc_num, self.acc_prob = acc_func(self.pred, self.y)
        self.global_step = tf.Variable(0, name='tr_global_step', trainable=False)

        self.opt = tf.train.GradientDescentOptimizer(learning_rate=self.init_lr)
        #self.opt = tf.train.MomentumOptimizer(learning_rate=self.init_lr, momentum=0.9)
        grads_and_vars = self.opt.compute_gradients(self.loss)
        clipped_grads_and_vars = [(tf.clip_by_norm(gv[0], self.max_grad_norm), gv[1]) \
                                    for gv in grads_and_vars]
        inc = self.global_step.assign_add(1)
        with tf.control_dependencies([inc]):
            self.optimizer = self.opt.apply_gradients(clipped_grads_and_vars)
        self.true_y = tf.argmax(self.y, 1)
        self.pred_y = tf.argmax(self.pred, 1)

    def get_batch_data(self, x, x_len, target, target_len, y, sentence_pos, asp_list, kp1, kp2, enable_alignment_loss, is_shuffle=True):
        if not enable_alignment_loss:
            for index in batch_index(len(y), self.batch_size, is_shuffle):
                feed_dict = {
                    self.real_batch_size: len(index),
                    self.x: x[index],
                    self.sentence_len: x_len[index],
                    self.target: target[index],
                    self.target_len: target_len[index],
                    self.y: y[index],
                    self.sentence_pos: sentence_pos[index],
                    self.keep_prob1: kp1,
                    self.keep_prob2: kp2,
                }
                yield feed_dict, len(index)
        else:
            for doc_index in batch_index(len(asp_list), self.batch_size, is_shuffle):
                index = []
                # the index in the batch
                # batch_index = []
                for doc in doc_index:
                    for aid in asp_list[doc]:
                        if aid == -1: break
                        index.append(aid)
                feed_dict = {
                    self.real_batch_size: len(index),
                    self.x: x[index],
                    self.sentence_len: x_len[index],
                    self.target: target[index],
                    self.target_len: target_len[index],
                    self.y: y[index],
                    self.sentence_pos: sentence_pos[index],
                    self.keep_prob1: kp1,
                    self.keep_prob2: kp2,
                }
                yield feed_dict, len(index)


    def train(self):
        x, x_len, target, target_len, label, sent_pos, asp_list = self.train_data
        cost = 0.0
        total = 0.0
        total_acc = 0
        N = len(x) // self.batch_size
        if self.enable_alignment_loss:
            N = len(asp_list) // self.batch_size
        if self.show:
            from utils import ProgressBar
            bar = ProgressBar('Train', max=N)
        for feed, num in self.get_batch_data(x, x_len, target, target_len, label, sent_pos, asp_list, self.kp1, self.kp2, self.enable_alignment_loss, True):
            _, step, _acc, _loss = self.sess.run([self.optimizer, self.global_step, self.acc_num, self.loss], feed_dict=feed)
            cost += np.sum(_loss)
            total += num
            total_acc += _acc
            if self.show: bar.next()
        if self.show:bar.finish()
        train_loss = cost / total
        train_acc = total_acc / total
        print 'train_loss: %.4f, train_acc: %.4f, acc_count: %d/%d' % (train_loss, train_acc, total_acc, total)
        return train_loss, train_acc

    def test(self):
        x, x_len, target, target_len, label, sent_pos, asp_list = self.test_data
        cost = 0.0
        total = 0.0
        total_acc = 0
        N = len(x) // self.batch_size

        # record the probability
        cur_true_y = []
        cur_pred_y = []
        cur_prob = []


        if self.enable_alignment_loss:
            N = len(asp_list) // self.batch_size
        if self.show:
            from utils import ProgressBar
            bar = ProgressBar('Test', max=N)
        for feed, num in self.get_batch_data(x, x_len, target, target_len, label, sent_pos, asp_list, 1.0, 1.0, self.enable_alignment_loss, False):
            _acc, _loss, prob, true_y, pred_y = self.sess.run([self.acc_num, self.loss, self.att_c, self.true_y, self.pred_y], feed_dict=feed)
            cur_true_y.extend(true_y)
            cur_pred_y.extend(pred_y)
            cur_prob.extend(prob)
            cost += np.sum(_loss)
            total += num
            total_acc += _acc
            if self.show: bar.next()
        if self.show:bar.finish()
        test_loss = cost / total
        test_acc = total_acc / total
        print 'test_loss: %.4f, test_acc: %.4f, acc_count: %d/%d' % (test_loss, test_acc, total_acc, total)
        return test_loss, test_acc, cur_true_y, cur_pred_y, cur_prob



    def run(self):
        self.build_model()
        self.sess.run(tf.global_variables_initializer())
        max_acc = 0.0
        max_true_y = []
        max_pred_y = []
        max_prob = []
        for idx in range(self.nepoch):
            print 'epoch %d...' % idx
            train_loss, train_acc = self.train()
            test_loss, test_acc, cur_true_y, cur_pred_y, cur_prob = self.test()
            if test_acc > max_acc:
                max_acc = test_acc
                max_true_y = cur_true_y
                max_pred_y = cur_pred_y
                max_prob = cur_prob
            print 'current max test accuracy: %.4f' % max_acc

        fw = open(self.summary_dir+'/prob.txt', 'w')
        x, x_len, target, target_len, label, sent_pos, asp_list = self.test_data
        for i in range(len(x)):
            context, prob = '', ''
            for j in range(0, x_len[i]):
                context = context +' '+self.id_to_word[x[i][j]]
                prob = prob + ' ' + str(max_prob[i][j])
            out = '%d %d %s %s\n' % (max_true_y[i], max_pred_y[i], context, prob)
            fw.write(out)

