from progress.bar import Bar
import tensorflow as tf
import numpy as np

class ProgressBar(Bar):
    message = 'Loading'
    fill = '#'
    suffix = '%(percent).1f%% | ETA: %(eta)ds'


def loss_func(prob, y):
    reg_loss = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
    loss = tf.reduce_sum(tf.nn.softmax_cross_entropy_with_logits(logits=prob, labels=y)) + sum(reg_loss)
    return loss

def acc_func(prob, y):
    correct_pred = tf.equal(tf.argmax(prob, 1), tf.argmax(y, 1))
    acc_num = tf.reduce_sum(tf.cast(correct_pred, tf.int32))
    acc_prob = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
    return acc_num, acc_prob

def change_y_to_onehot(y):
    from collections import Counter
    print Counter(y)
    class_set = set(y)
    n_class = len(class_set)
    y_onehot_mapping = dict(zip(class_set, range(n_class)))
    print y_onehot_mapping
    onehot = []
    for label in y:
        tmp = [0] * n_class
        tmp[y_onehot_mapping[label]] = 1
        onehot.append(tmp)
    return np.asarray(onehot, dtype=np.int32)

def batch_index(length, batch_size, is_shuffle=True):
    index = range(length)
    if is_shuffle:
        np.random.shuffle(index)
    for i in xrange(int(length / batch_size)  + (1 if length % batch_size else 0)):
        yield index[i * batch_size:(i + 1) * batch_size]

def load_word_dict(file_list):
    word_dict = {}
    for fname in file_list:
        lines = open(fname).readlines()
        for i in xrange(0, len(lines), 3):
            words = lines[i].decode('utf8').lower().split() + lines[i + 1].decode('utf8').lower().split()
            for w in words:
                word_dict[w] = True
    return word_dict

def load_w2v(w2v_file, embedding_dim, valid_word_dict, is_skip=False):
    fp = open(w2v_file)
    if is_skip:
        fp.readline()
    w2v = []
    word_dict = dict()
    # [0,0,...,0] represent absent words
    w2v.append([0.] * embedding_dim)
    cnt = 0
    for line in fp:
        line = line.decode('utf-8', 'ignore').split()
        # line = line.split()
        if len(line) != embedding_dim + 1:
            print 'a bad word embedding: {}'.format(line[0])
            continue
        if not valid_word_dict.has_key(line[0]):
            continue
        cnt += 1
        w2v.append([float(v) for v in line[1:]])
        word_dict[line[0]] = cnt
    w2v = np.asarray(w2v, dtype=np.float32)
    w2v = np.row_stack((w2v, np.sum(w2v, axis=0) / cnt))
    word_dict['$t$'] = (cnt + 1)
    # w2v -= np.mean(w2v, axis=0)
    # w2v /= np.std(w2v, axis=0)
    print word_dict['$t$'], len(w2v)
    id_to_word = {}
    for k, v in word_dict.items():
        id_to_word[v] = k
    id_to_word[0] = 'NULL'
    return word_dict, w2v, id_to_word

def extract_asp_list(doc_to_asp, max_asp_len):
    asp_list = []
    asp_len = []
    avg_asp_len = 0.0
    for k, v in doc_to_asp.items():
        avg_asp_len += len(v)
        asp_len.append(len(v))
        asp_list.append(v + [-1] * (max_asp_len - len(v)))
        #asp_list.append(v)
    print 'total doc size:', len(doc_to_asp)
    print 'avg asp count per doc: ', avg_asp_len / len(doc_to_asp)
    return asp_list, asp_len


def load_inputs(input_file, word_to_id, sentence_len, target_len):
    x, y, sen_len = [], [], []
    target_words = []
    tar_len = []
    sent_pos = []
    doc_to_asp = {}
    max_asp_len = 0
    lines = open(input_file).readlines()
    for i in xrange(0, len(lines), 3):
        words = lines[i + 1].decode('utf8').lower().split()
        target_word = []
        for w in words:
            if w in word_to_id:
                target_word.append(word_to_id[w])
        l = min(len(target_word), target_len)
        tar_len.append(l)
        target_words.append(target_word[:l] + [0] * (target_len - l))

        y.append(lines[i + 2].strip().split()[0])

        words = lines[i].decode('utf8').lower().split()
        words_id = []
        c_pos, t_pos = -1, -1
        s_pos = []
        for word in words:
            if word == '$t$':
                c_pos += 1
                t_pos = c_pos
                s_pos += ([t_pos] * l)
                words_id += target_word[:l]
                continue
            if word in word_to_id:
                c_pos += 1
                s_pos.append(c_pos)
                words_id.append(word_to_id[word])
        words = words_id[:sentence_len]

        doc = '-'.join([str(w) for w in words])
        if not doc_to_asp.has_key(doc):
            doc_to_asp[doc] = []
        doc_to_asp[doc].append(len(sen_len))
        max_asp_len = max(max_asp_len, len(doc_to_asp[doc]))

        sen_len.append(len(words))
        x.append(words + [0] * (sentence_len - len(words)))
        tmp_pos = []
        for pos in s_pos:
            if pos == t_pos:
                loc = 0.0
            else:
                loc = 1.0 - float(abs(pos - t_pos))/(len(s_pos)-l+1.0)
            tmp_pos.append(loc)
        s_pos = tmp_pos[:sentence_len]
        sent_pos.append(s_pos + [0] * (sentence_len - len(words)))
    print 'max aspects per document:', max_asp_len
    y = change_y_to_onehot(y)
    asp_list, asp_len = extract_asp_list(doc_to_asp, max_asp_len)
    return np.asarray(x, dtype=np.int32), np.asarray(sen_len, dtype=np.int32), np.asarray(target_words, dtype=np.int32), \
        np.asarray(tar_len, dtype=np.int32), np.asarray(y, dtype=np.int32), np.asarray(sent_pos, dtype=np.float32), \
        np.asarray(asp_list, dtype=np.int32)#, np.asarray(asp_len, dtype=np.int32)
