import tensorflow as tf
import numpy as np

def alignment_loss_func(target, align, label, batch_size, hidden_size, init_hid, l2_reg, alignment_loss_type):
    """
    compute aligment loss
    target: batch_size*hidden_size
    align: batch_size*1*max_sent_len
    label: batch_size*n_class
    """
    # target
    with tf.variable_scope("alignment_loss", reuse=tf.AUTO_REUSE):
        w = tf.get_variable(
            name = 'align_loss_w',
            shape = [hidden_size * 3, 1],
            initializer=tf.random_uniform_initializer(-init_hid, init_hid),
            regularizer=tf.contrib.layers.l2_regularizer(l2_reg)
        )
    TA = tf.tile(tf.expand_dims(target, 0), [batch_size, 1, 1])
    TB = tf.tile(tf.expand_dims(target, 1), [1, batch_size, 1])
    TC = tf.reshape(tf.concat([TA, TB, TA*TB], 2), [-1, hidden_size * 3])
    T_score = tf.nn.sigmoid(tf.reshape(tf.matmul(TC, w), [batch_size, batch_size]))

    align = tf.reshape(align, [batch_size, -1])
    AA = tf.tile(tf.expand_dims(align, 0), [batch_size, 1, 1])
    AB = tf.tile(tf.expand_dims(align, 1), [1, batch_size, 1])
    #A_score = tf.reshape(tf.reduce_mean(tf.square(tf.subtract(AA, AB)), reduction_indices=2), [batch_size, batch_size])
    A_score = tf.reshape(tf.reduce_sum(tf.square(tf.subtract(AA, AB)), reduction_indices=2) / 2.0, [batch_size, batch_size])


    LA = tf.tile(tf.expand_dims(tf.argmax(label, axis=1), 0), [batch_size, 1])
    LB = tf.tile(tf.expand_dims(tf.argmax(label, axis=1), 1), [1, batch_size])
    LC = tf.cast(tf.equal(LA, LB), tf.float32)
    if alignment_loss_type == 'neg':
        score = T_score * A_score * (LC - 1.0)
    elif alignment_loss_type == 'pos':
        score = T_score * A_score * LC
    elif alignment_loss_type == 'pos_neg':
        score = T_score * A_score * (LC - 1.0) + T_score * A_score * LC

    loss = tf.reduce_sum(score)
    return loss


def softsel(inputs, logits, mask):
    """
    softmax selection with mask.

    Arguments:
        inputs: [..., max_L, hidden_size]
        logits: [..., max_L]
        mask: [..., max_L]

    Returns:
        output: [..., hidden_size]
    """
    logits = tf.exp(logits) * mask
    _sum = tf.reduce_sum(logits, reduction_indices=-1, keep_dims=True) + 1e-9
    prob = logits / _sum
    i = inputs * tf.expand_dims(prob, -1)
    out = tf.reduce_sum(i, reduction_indices=-2)
    return out

def bi_directional_attention(context, query, c_len, c_mask, q_mask, init_hid, l2_reg, scope_name='bi_attention', layer_tag='1'):
    """
    bi-directional attention mechanism.

    Arguments:
        context: [batch_size, max_seq_len, hidden_size]
        query: [batch_size, max_query_len, hidden_size]
        c_mask: [batch_size, max_seq_len]
        q_mask: actual valid query length, [batch_size, max_query_len]

    Returns:
        context_a: [batch_size, max_seq_len, hidden_size]
        query_a[batch_size, max_seq_len, hidden_size]
    """
    CL = context.shape[1].value
    QL = query.shape[1].value
    hidden_size = context.shape[2].value
    context_avg = reduce_mean_with_len(context, c_len)
    context_aug = tf.tile(tf.expand_dims(context, 2), [1, 1, QL, 1])
    query_aug = tf.tile(tf.expand_dims(query, 1), [1, CL, 1, 1])
    c_aug_mask = tf.tile(tf.expand_dims(c_mask, 2), [1, 1, QL])
    q_aug_mask = tf.tile(tf.expand_dims(q_mask, 1), [1, CL, 1])
    with tf.variable_scope(scope_name, reuse=tf.AUTO_REUSE):
        w = tf.get_variable(
            name = 'bi_align_' + layer_tag,
            shape = [hidden_size * 3, 1],
            initializer=tf.random_uniform_initializer(-init_hid, init_hid),
            regularizer=tf.contrib.layers.l2_regularizer(l2_reg)
        )
    data = tf.reshape(tf.concat([context_aug, query_aug, context_aug * query_aug], 3), [-1, hidden_size*3])
    logits = tf.reshape(tf.matmul(data, w), [-1, CL, QL])
    query_a = reduce_mean_with_len(softsel(query_aug, logits, q_aug_mask), c_len)
    context_a = softsel(context, tf.reduce_max(logits, 2), c_mask)
    out = tf.concat([context_a, query_a], 1)
    return out

def get_mask_with_len(length, max_len):
    """
    Arguments:
        length: [batch_size,]
    Returns:
        out: [batch_size, max_len]
    """
    out = tf.cast(tf.sequence_mask(length, max_len), tf.float32)
    return out

def softmax_with_len(inputs, length, max_len):
    inputs = tf.cast(inputs, tf.float32)
    # max_axis = tf.reduce_max(inputs, -1, keep_dims=True)
    # inputs = tf.exp(inputs - max_axis)
    inputs = tf.exp(inputs)
    length = tf.reshape(length, [-1])
    mask = tf.reshape(tf.cast(tf.sequence_mask(length, max_len), tf.float32), tf.shape(inputs))
    inputs *= mask
    _sum = tf.reduce_sum(inputs, reduction_indices=-1, keep_dims=True) + 1e-9
    return inputs / _sum

def bilinear_attention_layer(inputs, attention, length, init_hid, l2_reg, scope_name='bilinear_att'):
    """
    Bilinear attention mechanism.

    Arguments:
        inputs: batch_size * max_len * n_hidden
        attention: batch_size * n_hidden
    Returns:
        out: batch_size * n_hidden
    """
    batch_size, max_len, n_hidden = inputs.shape
    with tf.variable_scope(scope_name, reuse=tf.AUTO_REUSE):
        w = tf.get_variable(
            name='bilinear_att_w',
            shape=[n_hidden, n_hidden],
            initializer=tf.random_uniform_initializer(-init_hid, init_hid),
            regularizer=tf.contrib.layers.l2_regularizer(l2_reg)
        )
    inputs = tf.reshape(inputs, [-1, n_hidden])
    tmp = tf.reshape(tf.matmul(inputs, w), [-1, max_len, n_hidden])
    attend = tf.expand_dims(attention, 2)
    weight = tf.reshape(tf.matmul(tmp, attend), [-1, 1, max_len])
    return softmax_with_len(weight, length, max_len)

def reduce_mean_with_len(inputs, length):
    """
    :param inputs: 3-D tensor
    :param length: the length of dim [1]
    :return: 2-D tensor
    """
    length = tf.cast(tf.reshape(length, [-1, 1]), tf.float32) + 1e-9
    inputs = tf.reduce_sum(inputs, 1, keep_dims=False) / length
    return inputs

def bi_dynamic_rnn(cell, inputs, n_hidden, length, max_len, scope_name, out_type='last'):
    """
    bidirectional_dynamic rnn
    """
    with tf.variable_scope(scope_name, reuse=tf.AUTO_REUSE):
        outputs, state = tf.nn.bidirectional_dynamic_rnn(
            cell_fw=cell(n_hidden),
            cell_bw=cell(n_hidden),
            inputs=inputs,
            sequence_length=length,
            dtype=tf.float32
        )
    all_outputs = tf.concat(outputs, 2)
    if out_type == 'last' or out_type == 'all_and_last':
        outputs_fw, outputs_bw = outputs
        outputs_bw = tf.reverse_sequence(outputs_bw, tf.cast(length, tf.int64), seq_dim=1)
        outputs = tf.concat([outputs_fw, outputs_bw], 2)
    else:
        outputs = tf.concat(outputs, 2)  # batch_size * max_len * 2n_hidden
    batch_size = tf.shape(outputs)[0]
    if out_type == 'last' or out_type == 'all_and_last':
        index = tf.range(0, batch_size) * max_len + (length - 1)
        last_outputs = tf.gather(tf.reshape(outputs, [-1, 2 * n_hidden]), index)  # batch_size * 2n_hidden
        return all_outputs, last_outputs
    elif out_type == 'all_and_avg':
        avg_outputs = reduce_mean_with_len(outputs, length)  # batch_size * 2n_hidden
        return all_outputs, avg_outputs
    return outputs

def softmax_layer(inputs, n_hidden, init_hid, keep_prob, n_class, l2_reg, scope_name='softmax'):
    with tf.variable_scope(scope_name, reuse=tf.AUTO_REUSE):
        w = tf.get_variable(
            name='softmax_w',
            shape=[n_hidden, n_class],
            initializer=tf.random_normal_initializer(mean=0., stddev=np.sqrt(2. / (n_hidden + n_class))),
            regularizer=tf.contrib.layers.l2_regularizer(l2_reg)
            # initializer=tf.random_uniform_initializer(-random_base, random_base),
            # initializer=tf.random_uniform_initializer(-np.sqrt(6.0 / (n_hidden + n_class)), np.sqrt(6.0 / (n_hidden + n_class))),
        )
        b = tf.get_variable(
            name='softmax_b',
            shape=[n_class],
            initializer=tf.random_normal_initializer(mean=0., stddev=np.sqrt(2. / (n_class))),
            # initializer=tf.random_uniform_initializer(-random_base, random_base),
            regularizer=tf.contrib.layers.l2_regularizer(l2_reg)
        )
        outputs = tf.nn.dropout(inputs, keep_prob=keep_prob)
        predict = tf.matmul(outputs, w) + b
    return predict



